import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MapPin, i as Menu, o as Check, r as Phone, t as X } from "../_libs/lucide-react.mjs";
import { a as PHONE_TEL, c as brands, d as nav, f as photos, h as waLink, i as PHONE_DISPLAY, l as checks, m as steps, n as ADDRESS, o as WA_GERAL, p as services, r as MAPS_URL, s as WHATSAPP_DISPLAY, u as faqs } from "./router-C3ELzpSj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D-RbPW7l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function WhatsAppIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		className: "whatsapp-icon",
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.496.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.5-.669-.51-.173-.009-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479s1.065 2.875 1.213 3.074c.149.198 2.095 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.981.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.89-9.884a9.821 9.821 0 0 1 7.021 2.91 9.825 9.825 0 0 1 2.9 7.03c-.002 5.45-4.437 9.884-9.927 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" })
	});
}
function ServiceGlyph({ name }) {
	const props = {
		className: "service-glyph",
		viewBox: "0 0 32 32",
		fill: "none",
		"aria-hidden": true
	};
	if (name === "rocadeira") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "5",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 3v6M16 23v6M3 16h6M23 16h6",
			stroke: "currentColor",
			strokeWidth: "1.7"
		})]
	});
	if (name === "motosserra") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 20h14l6-6H12L6 20Z",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 20v4M20 14V8",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinecap: "round"
		})]
	});
	if (name === "lavadora") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 5c4 5 7 8 7 12a7 7 0 0 1-14 0c0-4 3-7 7-12Z",
			stroke: "currentColor",
			strokeWidth: "1.7"
		})
	});
	if (name === "motor") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "4",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M16 4v3M16 25v3M4 16h3M25 16h3M7.5 7.5l2.2 2.2M22.3 22.3l2.2 2.2M24.5 7.5l-2.2 2.2M9.7 22.3l-2.2 2.2",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinecap: "round"
		})]
	});
	if (name === "cultivo") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M5 22h22M8 22V14h6v8M18 22V10h6v12",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinejoin: "round"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "10",
			stroke: "currentColor",
			strokeWidth: "1.7"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 16.5 14 20.5 22 12",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})]
	});
}
function HomePage() {
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		document.body.classList.toggle("nav-open", open);
		return () => document.body.classList.remove("nav-open");
	}, [open]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(false);
		};
		const onClick = (event) => {
			const link = event.target?.closest?.("a[href*='wa.me/']");
			if (!link || typeof window.gtag !== "function") return;
			window.gtag("event", "whatsapp_click", {
				link_url: link.href,
				link_text: (link.textContent || "").trim(),
				event_category: "contato",
				event_label: "Ferrari Oficina - WhatsApp",
				transport_type: "beacon"
			});
		};
		document.addEventListener("keydown", onKey);
		document.addEventListener("click", onClick);
		return () => {
			document.removeEventListener("keydown", onKey);
			document.removeEventListener("click", onClick);
		};
	}, []);
	const close = () => setOpen(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "skip",
			href: "#conteudo",
			children: "Ir para o conteúdo"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "topbar",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "brand",
					href: "#inicio",
					"aria-label": "Oficina João Ferrari — início",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "brand-logo",
						src: "/oficina/logo-oficina.webp",
						alt: "",
						width: "900",
						height: "900"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "OFICINA JOÃO FERRARI" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Manutenção • Peças • Confiança" })] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "desk-nav",
					"aria-label": "Navegação principal",
					children: nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: item.href,
						children: item.label
					}, item.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					className: "call-pill",
					href: `tel:${PHONE_TEL}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
						className: "ui-icon",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: PHONE_DISPLAY })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "menu-toggle",
					type: "button",
					"aria-expanded": open,
					"aria-controls": "menu-mobile",
					onClick: () => setOpen((value) => !value),
					children: [open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "ui-icon" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "ui-icon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: open ? "Fechar menu" : "Abrir menu"
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			id: "menu-mobile",
			className: open ? "nav-panel open" : "nav-panel",
			"aria-label": "Menu",
			"aria-hidden": !open,
			children: [
				nav.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: item.href,
					onClick: close,
					children: item.label
				}, item.href)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#trabalhos",
					onClick: close,
					children: "Bancada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#contato",
					onClick: close,
					children: "Contato"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nav-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "primary",
						href: WA_GERAL,
						target: "_blank",
						rel: "noreferrer",
						onClick: close,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), "WhatsApp"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "secondary",
						href: `tel:${PHONE_TEL}`,
						onClick: close,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "ui-icon",
								"aria-hidden": "true"
							}),
							"Ligar ",
							PHONE_DISPLAY
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			id: "conteudo",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "hero",
					id: "inicio",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hero-grid",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-copy",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "eyebrow",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Assistência técnica em Potirendaba e região"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "display",
									children: ["Seu equipamento ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "de volta ao trabalho." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "lead",
									children: "A Oficina João Ferrari faz diagnóstico cuidadoso, orçamento transparente e manutenção de roçadeiras, motosserras, lavadoras e motores a combustão em Potirendaba/SP."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hero-actions",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										className: "primary",
										href: WA_GERAL,
										target: "_blank",
										rel: "noreferrer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Solicitar orçamento" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										className: "secondary",
										href: "#servicos",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Conhecer serviços" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "quick-trust",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "tick",
											"aria-hidden": "true"
										}), " Orçamento antes do reparo"] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "tick",
											"aria-hidden": "true"
										}), " Serviço com garantia"] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "tick",
											"aria-hidden": "true"
										}), " Atendimento direto"] })
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hero-visual",
							"aria-label": "Logotipo da Oficina João Ferrari",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "machine-card",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "status",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}), " EQUIPAMENTO EM REVISÃO"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											className: "hero-logo-image",
											src: "/oficina/logo-oficina.webp",
											alt: "Oficina João Ferrari — Manutenção, Peças e Confiança",
											width: "900",
											height: "900"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "diagnostic",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "DIAGNÓSTICO" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Preciso e transparente" })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "float-card fc-one",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "+ vida útil" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "com manutenção preventiva" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "float-card fc-two",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Potirendaba • SP" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "atendimento com hora marcada" })]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "numbers",
					"aria-label": "Como é o atendimento",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "01" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Diagnóstico",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"responsável"
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "02" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Orçamento",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"detalhado"
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "03" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Reparo e",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"testes finais"
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "04" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Entrega com",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"orientação"
						] })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "section services",
					id: "servicos",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "section-heading",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "eyebrow dark",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " O que fazemos"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "display",
							children: ["Manutenção que ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "resolve de verdade." })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atendimento multimarcas para equipamentos usados no campo, jardim, construção e rotina doméstica." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "service-grid",
						children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "service-card",
							id: service.id,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "service-number",
									children: service.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceGlyph, { name: service.glyph }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: service.title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: service.text }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: service.href,
									target: "_blank",
									rel: "noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), " Consultar serviço"]
								})
							]
						}, service.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "process",
					id: "processo",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "process-intro",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "eyebrow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Simples do começo ao fim"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "display",
								children: ["Você sabe o que será feito ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "antes de aprovar." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "prose",
								children: "Nada de surpresa na entrega. Avaliamos o equipamento e explicamos o diagnóstico, as peças e a mão de obra."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "primary",
								href: WA_GERAL,
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), " Iniciar atendimento"]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "steps",
						children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: step.n }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: step.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: step.text })] })] }, step.n))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "section real-work",
					id: "trabalhos",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "section-heading",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "eyebrow dark",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Equipamentos reais"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "display",
							children: ["Direto da ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "nossa bancada." })]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Alguns dos equipamentos que chegam à Oficina João Ferrari para diagnóstico, manutenção e recuperação." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "gallery-grid",
						children: photos.map((photo, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: photo.square ? `work-photo is-square photo-${index + 1}` : `work-photo photo-${index + 1}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "photo-backdrop",
									style: { backgroundImage: `url(${photo.src})` },
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: photo.src,
									alt: photo.alt,
									width: photo.w,
									height: photo.h,
									loading: "lazy",
									decoding: "async"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["0", index + 1] }), photo.caption] })
							]
						}, photo.src))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "section",
					id: "oficina",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "prevention-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "prevention-art",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "portrait-frame",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/oficina/joao-ferrari.webp",
									alt: "João Ferrari, responsável pela Oficina João Ferrari",
									width: "235",
									height: "378",
									loading: "lazy"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tag",
									children: [
										"ATENDIMENTO DIRETO",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"COM JOÃO FERRARI"
									]
								})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "prevention-copy",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "eyebrow dark",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Cuidado inteligente"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "display",
									children: ["Manutenção preventiva ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "protege seu investimento." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "prose",
									children: "Máquina parada atrasa o serviço. Uma revisão periódica ajuda a identificar desgaste antes que ele vire um reparo maior."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: checks.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "aria-hidden": "true" }), item] }, item)) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "primary",
									href: waLink("Olá, João! Gostaria de agendar uma revisão preventiva."),
									target: "_blank",
									rel: "noreferrer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), " Agendar revisão"]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "brands",
					"aria-label": "Marcas atendidas",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "PRINCIPAIS MARCAS ATENDIDAS" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "brand-row",
							children: brands.map((brand) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: brand }, brand))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Oficina multimarcas independente. As marcas pertencem aos seus respectivos proprietários." })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "section faq",
					id: "duvidas",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "faq-intro",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "eyebrow dark",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Perguntas e respostas"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "display",
								children: ["Dúvidas antes de ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "trazer sua máquina?" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "prose",
								children: "Aqui estão as respostas rápidas. Se ainda ficar alguma dúvida, fale diretamente com o João."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "primary",
								href: waLink("Olá, João! Tenho uma dúvida sobre o atendimento da oficina."),
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Tirar uma dúvida" })]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "faq-list",
						children: faqs.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["0", index + 1] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: item.q }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
								className: "faq-plus",
								"aria-hidden": "true",
								children: "+"
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.a })] }, item.q))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "contact",
					id: "contato",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "eyebrow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), " Vamos conversar?"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "display",
							children: ["Não deixe o equipamento ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: "parado por mais tempo." })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "prose",
							children: "Fale diretamente com João Ferrari e explique o que está acontecendo."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "contact-stack",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "contact-button",
								href: WA_GERAL,
								target: "_blank",
								rel: "noreferrer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "wa",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "ATENDIMENTO PELO WHATSAPP" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: WHATSAPP_DISPLAY })] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "contact-button phone-only",
								href: `tel:${PHONE_TEL}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "wa",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
										className: "ui-icon",
										"aria-hidden": "true"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "TELEFONE PARA LIGAÇÕES" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: PHONE_DISPLAY })] })]
							})]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: "brand",
				href: "#inicio",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: "brand-logo",
					src: "/oficina/logo-oficina.webp",
					alt: "",
					width: "900",
					height: "900"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "OFICINA JOÃO FERRARI" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: "Manutenção • Peças • Confiança" })] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: ADDRESS.street }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [ADDRESS.city, " • São Paulo"] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Atendimento com hora marcada" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${PHONE_TEL}`,
					children: ["Telefone ", PHONE_DISPLAY]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: WA_GERAL,
					target: "_blank",
					rel: "noreferrer",
					children: ["WhatsApp ", WHATSAPP_DISPLAY]
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: MAPS_URL,
					target: "_blank",
					rel: "noreferrer",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
						className: "ui-icon",
						"aria-hidden": "true"
					}), " Como chegar"]
				}) })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" Oficina João Ferrari",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
				"Oficina multimarcas independente."
			] })
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
			className: "whatsapp-float",
			href: WA_GERAL,
			target: "_blank",
			rel: "noreferrer",
			"aria-label": "Falar no WhatsApp",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "WhatsApp" })]
		})
	] });
}
var SplitComponent = HomePage;
//#endregion
export { SplitComponent as component };
