import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-C3ELzpSj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-BEXjNtWL.css";
var GA_ID = "G-42Q6C4H18P";
var Route$1 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{
				name: "theme-color",
				content: "#0d0e0c"
			},
			{
				name: "format-detection",
				content: "telephone=yes"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preload",
				href: "/fonts/barlow-condensed-700.woff2",
				as: "font",
				type: "font/woff2",
				crossOrigin: "anonymous"
			},
			{
				rel: "preload",
				href: "/fonts/manrope-400.woff2",
				as: "font",
				type: "font/woff2",
				crossOrigin: "anonymous"
			}
		]
	}),
	component: Root
});
function Root() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				async: true,
				src: `https://www.googletagmanager.com/gtag/js?id=${GA_ID}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${GA_ID}');` } })
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var PHONE_DISPLAY = "(17) 3199-0596";
var PHONE_TEL = "+551731990596";
var WHATSAPP_DISPLAY = "(17) 99117-3799";
var WHATSAPP_TEL = "5517991173799";
var ADDRESS = {
	street: "Rodovia Luiz Carlos Brandolezi, km 07",
	city: "Potirendaba",
	region: "SP",
	country: "BR"
};
var MAPS_URL = "https://www.google.com/maps/search/?api=1&query=Rodovia%20Luiz%20Carlos%20Brandolezi%2C%20km%2007%2C%20Potirendaba%20-%20SP";
function waLink(text) {
	return `https://wa.me/${WHATSAPP_TEL}?text=${encodeURIComponent(text)}`;
}
var WA_GERAL = waLink("Olá, João! Gostaria de solicitar um orçamento para meu equipamento.");
var seo = {
	title: "Oficina João Ferrari | Motosserras e Roçadeiras em Potirendaba",
	description: "Assistência técnica em Potirendaba/SP para roçadeiras, motosserras, lavadoras, motores estacionários e motocultivadores. Orçamento antes do reparo e garantia."
};
var services = [
	{
		id: "rocadeiras",
		n: "01",
		title: "Roçadeiras",
		text: "Limpeza, regulagem, partida, embreagem e revisão completa.",
		glyph: "rocadeira",
		href: waLink("Olá, João! Gostaria de um orçamento para minha roçadeira.")
	},
	{
		id: "motosserras",
		n: "02",
		title: "Motosserras",
		text: "Diagnóstico, afiação, carburador, lubrificação e conjunto de corte.",
		glyph: "motosserra",
		href: waLink("Olá, João! Gostaria de um orçamento para minha motosserra.")
	},
	{
		id: "lavadoras",
		n: "03",
		title: "Lavadoras",
		text: "Reparo de bombas, vazamentos, perda de pressão e revisão preventiva.",
		glyph: "lavadora",
		href: waLink("Olá, João! Gostaria de um orçamento para minha lavadora.")
	},
	{
		id: "motores",
		n: "04",
		title: "Motores estacionários",
		text: "Manutenção em motores a gasolina de diferentes potências e marcas.",
		glyph: "motor",
		href: waLink("Olá, João! Gostaria de um orçamento para meu motor estacionário.")
	},
	{
		id: "motocultivadores",
		n: "05",
		title: "Motocultivadores",
		text: "Revisão de motor, sistema de partida, transmissão e regulagens.",
		glyph: "cultivo",
		href: waLink("Olá, João! Gostaria de um orçamento para meu motocultivador.")
	},
	{
		id: "revisao",
		n: "06",
		title: "Revisão preventiva",
		text: "Check-up para reduzir falhas, gastos inesperados e tempo parado.",
		glyph: "revisao",
		href: waLink("Olá, João! Gostaria de agendar uma revisão preventiva.")
	}
];
var steps = [
	{
		n: "01",
		title: "Conte o problema",
		text: "Envie uma mensagem com a marca, modelo e sintomas do equipamento."
	},
	{
		n: "02",
		title: "Avaliação técnica",
		text: "O equipamento é inspecionado para localizar a causa real da falha."
	},
	{
		n: "03",
		title: "Aprovação do orçamento",
		text: "Você recebe o valor antes do serviço e decide com tranquilidade."
	},
	{
		n: "04",
		title: "Reparo, testes e entrega",
		text: "Depois do conserto, fazemos os testes necessários antes da retirada."
	}
];
var photos = [
	{
		src: "/oficina/motosserra-stihl.webp",
		alt: "Motosserra Stihl recebida para manutenção na Oficina João Ferrari",
		caption: "Motosserras",
		w: 900,
		h: 1200,
		square: false
	},
	{
		src: "/oficina/rocadeira-stihl.webp",
		alt: "Roçadeira Stihl na Oficina João Ferrari",
		caption: "Roçadeiras",
		w: 1200,
		h: 1200,
		square: true
	},
	{
		src: "/oficina/motocultivador-kawashima.webp",
		alt: "Motocultivador Kawashima em revisão",
		caption: "Motocultivadores",
		w: 900,
		h: 1200,
		square: false
	},
	{
		src: "/oficina/rocadeira-husqvarna.webp",
		alt: "Motor de roçadeira Husqvarna em avaliação",
		caption: "Diagnóstico",
		w: 1200,
		h: 1200,
		square: true
	},
	{
		src: "/oficina/cortador-grama.webp",
		alt: "Cortador de grama na oficina",
		caption: "Motores em geral",
		w: 900,
		h: 1200,
		square: false
	}
];
var brands = [
	"STIHL",
	"Husqvarna",
	"Branco",
	"Toyama",
	"Buffalo",
	"Kärcher",
	"Tekna",
	"Kawashima",
	"Trapp"
];
var checks = [
	"Limpeza e inspeção geral",
	"Verificação de filtros, vela e combustível",
	"Regulagem e teste de funcionamento",
	"Orientação para conservação e uso"
];
var faqs = [
	{
		q: "Quais equipamentos vocês consertam?",
		a: "Atendemos roçadeiras, motosserras, lavadoras, motores estacionários, motocultivadores, cortadores de grama e outros equipamentos a gasolina."
	},
	{
		q: "Como funciona o orçamento?",
		a: "Primeiro fazemos a avaliação técnica para encontrar a causa da falha. Depois, você recebe o valor do serviço e das peças antes de autorizar o reparo."
	},
	{
		q: "A oficina atende várias marcas?",
		a: "Sim. A Oficina João Ferrari é multimarcas e trabalha com equipamentos de fabricantes como STIHL, Husqvarna, Branco, Toyama, Buffalo, Kärcher, Tekna, Kawashima e Trapp."
	},
	{
		q: "Preciso agendar o atendimento?",
		a: "O atendimento é feito com hora marcada. Chame no WhatsApp antes de levar o equipamento para combinarmos o melhor horário."
	},
	{
		q: "O serviço tem garantia?",
		a: "Sim. A garantia varia conforme o tipo de reparo e as peças utilizadas; as condições são explicadas com clareza na entrega."
	},
	{
		q: "Onde fica a Oficina João Ferrari?",
		a: "Estamos na Rodovia Luiz Carlos Brandolezi, km 07, em Potirendaba, São Paulo. O atendimento é com hora marcada."
	}
];
var nav = [
	{
		href: "#servicos",
		label: "Serviços"
	},
	{
		href: "#processo",
		label: "Como funciona"
	},
	{
		href: "#oficina",
		label: "A oficina"
	},
	{
		href: "#duvidas",
		label: "Dúvidas"
	}
];
var jsonLd = {
	"@context": "https://schema.org",
	"@graph": [{
		"@type": ["AutoRepair", "LocalBusiness"],
		"@id": "#oficina-joao-ferrari",
		name: "Oficina João Ferrari",
		alternateName: ["Ferrari Oficina", "JF Oficina Especializada"],
		description: seo.description,
		slogan: "Manutenção, peças e confiança",
		telephone: ["+5517991173799", "+551731990596"],
		address: {
			"@type": "PostalAddress",
			streetAddress: ADDRESS.street,
			addressLocality: ADDRESS.city,
			addressRegion: ADDRESS.region,
			addressCountry: ADDRESS.country
		},
		areaServed: [{
			"@type": "City",
			name: "Potirendaba"
		}, {
			"@type": "AdministrativeArea",
			name: "São Paulo"
		}],
		hasMap: MAPS_URL,
		currenciesAccepted: "BRL",
		knowsAbout: [
			"Manutenção de roçadeiras",
			"Manutenção de motosserras",
			"Lavadoras de alta pressão",
			"Motores estacionários a gasolina",
			"Motocultivadores",
			"Cortadores de grama"
		],
		brand: brands.map((name) => ({
			"@type": "Brand",
			name
		})),
		makesOffer: services.map((service) => ({
			"@type": "Offer",
			itemOffered: {
				"@type": "Service",
				name: service.title,
				description: service.text,
				areaServed: "Potirendaba, SP",
				provider: { "@id": "#oficina-joao-ferrari" }
			}
		}))
	}, {
		"@type": "FAQPage",
		mainEntity: faqs.map((item) => ({
			"@type": "Question",
			name: item.q,
			acceptedAnswer: {
				"@type": "Answer",
				text: item.a
			}
		}))
	}]
};
var $$splitComponentImporter = () => import("./routes-D-RbPW7l.mjs");
var rootRouteChildren = { IndexRoute: createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: seo.title },
			{
				name: "description",
				content: seo.description
			},
			{
				name: "robots",
				content: "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
			},
			{
				name: "author",
				content: "João Ferrari"
			},
			{
				name: "geo.region",
				content: "BR-SP"
			},
			{
				name: "geo.placename",
				content: "Potirendaba"
			},
			{
				name: "language",
				content: "pt-BR"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Oficina João Ferrari"
			},
			{ "script:ld+json": jsonLd }
		],
		links: [{
			rel: "preload",
			href: "/oficina/logo-oficina.webp",
			as: "image"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter, "component")
}).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { PHONE_TEL as a, brands as c, nav as d, photos as f, waLink as h, PHONE_DISPLAY as i, checks as l, steps as m, ADDRESS as n, WA_GERAL as o, services as p, MAPS_URL as r, WHATSAPP_DISPLAY as s, router_exports as t, faqs as u };
