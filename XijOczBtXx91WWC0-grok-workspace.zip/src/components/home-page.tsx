import { useEffect, useState } from "react";
import { Check, MapPin, Menu, Phone, X } from "lucide-react";
import {
  ADDRESS,
  brands,
  checks,
  faqs,
  MAPS_URL,
  nav,
  PHONE_DISPLAY,
  PHONE_TEL,
  photos,
  services,
  steps,
  WA_GERAL,
  waLink,
  WHATSAPP_DISPLAY,
} from "@/data/site";

function WhatsAppIcon() {
  return (
    <svg className="whatsapp-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.496.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.5-.669-.51-.173-.009-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479s1.065 2.875 1.213 3.074c.149.198 2.095 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.981.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.89-9.884a9.821 9.821 0 0 1 7.021 2.91 9.825 9.825 0 0 1 2.9 7.03c-.002 5.45-4.437 9.884-9.927 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
    </svg>
  );
}

function ServiceGlyph({ name }: { name: string }) {
  const props = {
    className: "service-glyph",
    viewBox: "0 0 32 32",
    fill: "none",
    "aria-hidden": true as const,
  };
  if (name === "rocadeira") {
    return (
      <svg {...props}>
        <circle cx="16" cy="16" r="5" stroke="currentColor" strokeWidth="1.7" />
        <path d="M16 3v6M16 23v6M3 16h6M23 16h6" stroke="currentColor" strokeWidth="1.7" />
      </svg>
    );
  }
  if (name === "motosserra") {
    return (
      <svg {...props}>
        <path d="M6 20h14l6-6H12L6 20Z" stroke="currentColor" strokeWidth="1.7" />
        <path d="M8 20v4M20 14V8" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
      </svg>
    );
  }
  if (name === "lavadora") {
    return (
      <svg {...props}>
        <path d="M16 5c4 5 7 8 7 12a7 7 0 0 1-14 0c0-4 3-7 7-12Z" stroke="currentColor" strokeWidth="1.7" />
      </svg>
    );
  }
  if (name === "motor") {
    return (
      <svg {...props}>
        <circle cx="16" cy="16" r="4" stroke="currentColor" strokeWidth="1.7" />
        <path
          d="M16 4v3M16 25v3M4 16h3M25 16h3M7.5 7.5l2.2 2.2M22.3 22.3l2.2 2.2M24.5 7.5l-2.2 2.2M9.7 22.3l-2.2 2.2"
          stroke="currentColor"
          strokeWidth="1.7"
          strokeLinecap="round"
        />
      </svg>
    );
  }
  if (name === "cultivo") {
    return (
      <svg {...props}>
        <path d="M5 22h22M8 22V14h6v8M18 22V10h6v12" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      </svg>
    );
  }
  return (
    <svg {...props}>
      <circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="1.7" />
      <path d="M10 16.5 14 20.5 22 12" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function HomePage() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.classList.toggle("nav-open", open);
    return () => document.body.classList.remove("nav-open");
  }, [open]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    const onClick = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      const link = target?.closest?.("a[href*='wa.me/']");
      if (!link || typeof window.gtag !== "function") return;
      window.gtag("event", "whatsapp_click", {
        link_url: (link as HTMLAnchorElement).href,
        link_text: (link.textContent || "").trim(),
        event_category: "contato",
        event_label: "Ferrari Oficina - WhatsApp",
        transport_type: "beacon",
      });
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("click", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("click", onClick);
    };
  }, []);

  const close = () => setOpen(false);

  return (
    <>
      <a className="skip" href="#conteudo">
        Ir para o conteúdo
      </a>
      <header className="topbar">
        <a className="brand" href="#inicio" aria-label="Oficina João Ferrari — início">
          <img className="brand-logo" src="/oficina/logo-oficina.webp" alt="" width="900" height="900" />
          <span>
            <strong>OFICINA JOÃO FERRARI</strong>
            <small>Manutenção • Peças • Confiança</small>
          </span>
        </a>
        <nav className="desk-nav" aria-label="Navegação principal">
          {nav.map((item) => (
            <a key={item.href} href={item.href}>
              {item.label}
            </a>
          ))}
        </nav>
        <a className="call-pill" href={`tel:${PHONE_TEL}`}>
          <Phone className="ui-icon" aria-hidden="true" />
          <span>{PHONE_DISPLAY}</span>
        </a>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={open}
          aria-controls="menu-mobile"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? <X className="ui-icon" /> : <Menu className="ui-icon" />}
          <span className="sr-only">{open ? "Fechar menu" : "Abrir menu"}</span>
        </button>
      </header>

      <nav
        id="menu-mobile"
        className={open ? "nav-panel open" : "nav-panel"}
        aria-label="Menu"
        aria-hidden={!open}
      >
        {nav.map((item) => (
          <a key={item.href} href={item.href} onClick={close}>
            {item.label}
          </a>
        ))}
        <a href="#trabalhos" onClick={close}>
          Bancada
        </a>
        <a href="#contato" onClick={close}>
          Contato
        </a>
        <div className="nav-actions">
          <a className="primary" href={WA_GERAL} target="_blank" rel="noreferrer" onClick={close}>
            <WhatsAppIcon />
            WhatsApp
          </a>
          <a className="secondary" href={`tel:${PHONE_TEL}`} onClick={close}>
            <Phone className="ui-icon" aria-hidden="true" />
            Ligar {PHONE_DISPLAY}
          </a>
        </div>
      </nav>

      <main id="conteudo">
        <section className="hero" id="inicio">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-copy">
            <p className="eyebrow">
              <span /> Assistência técnica em Potirendaba e região
            </p>
            <h1 className="display">
              Seu equipamento <em>de volta ao trabalho.</em>
            </h1>
            <p className="lead">
              A Oficina João Ferrari faz diagnóstico cuidadoso, orçamento transparente e manutenção de
              roçadeiras, motosserras, lavadoras e motores a combustão em Potirendaba/SP.
            </p>
            <div className="hero-actions">
              <a className="primary" href={WA_GERAL} target="_blank" rel="noreferrer">
                <WhatsAppIcon />
                <b>Solicitar orçamento</b>
              </a>
              <a className="secondary" href="#servicos">
                <b>Conhecer serviços</b>
              </a>
            </div>
            <div className="quick-trust">
              <span>
                <Check className="tick" aria-hidden="true" /> Orçamento antes do reparo
              </span>
              <span>
                <Check className="tick" aria-hidden="true" /> Serviço com garantia
              </span>
              <span>
                <Check className="tick" aria-hidden="true" /> Atendimento direto
              </span>
            </div>
          </div>
          <div className="hero-visual" aria-label="Logotipo da Oficina João Ferrari">
            <div className="machine-card">
              <span className="status">
                <i /> EQUIPAMENTO EM REVISÃO
              </span>
              <img
                className="hero-logo-image"
                src="/oficina/logo-oficina.webp"
                alt="Oficina João Ferrari — Manutenção, Peças e Confiança"
                width="900"
                height="900"
              />
              <div className="diagnostic">
                <span>DIAGNÓSTICO</span>
                <b>Preciso e transparente</b>
              </div>
            </div>
            <div className="float-card fc-one">
              <b>+ vida útil</b>
              <span>com manutenção preventiva</span>
            </div>
            <div className="float-card fc-two">
              <b>Potirendaba • SP</b>
              <span>atendimento com hora marcada</span>
            </div>
          </div>
        </section>

        <section className="numbers" aria-label="Como é o atendimento">
          <div>
            <b>01</b>
            <span>
              Diagnóstico
              <br />
              responsável
            </span>
          </div>
          <div>
            <b>02</b>
            <span>
              Orçamento
              <br />
              detalhado
            </span>
          </div>
          <div>
            <b>03</b>
            <span>
              Reparo e
              <br />
              testes finais
            </span>
          </div>
          <div>
            <b>04</b>
            <span>
              Entrega com
              <br />
              orientação
            </span>
          </div>
        </section>

        <section className="section services" id="servicos">
          <div className="section-heading">
            <div>
              <p className="eyebrow dark">
                <span /> O que fazemos
              </p>
              <h2 className="display">
                Manutenção que <em>resolve de verdade.</em>
              </h2>
            </div>
            <p>
              Atendimento multimarcas para equipamentos usados no campo, jardim, construção e rotina
              doméstica.
            </p>
          </div>
          <div className="service-grid">
            {services.map((service) => (
              <article className="service-card" key={service.id} id={service.id}>
                <span className="service-number">{service.n}</span>
                <ServiceGlyph name={service.glyph} />
                <h3>{service.title}</h3>
                <p>{service.text}</p>
                <a href={service.href} target="_blank" rel="noreferrer">
                  <WhatsAppIcon /> Consultar serviço
                </a>
              </article>
            ))}
          </div>
        </section>

        <section className="process" id="processo">
          <div className="process-intro">
            <p className="eyebrow">
              <span /> Simples do começo ao fim
            </p>
            <h2 className="display">
              Você sabe o que será feito <em>antes de aprovar.</em>
            </h2>
            <p className="prose">
              Nada de surpresa na entrega. Avaliamos o equipamento e explicamos o diagnóstico, as peças e a
              mão de obra.
            </p>
            <a className="primary" href={WA_GERAL} target="_blank" rel="noreferrer">
              <WhatsAppIcon /> Iniciar atendimento
            </a>
          </div>
          <ol className="steps">
            {steps.map((step) => (
              <li key={step.n}>
                <b>{step.n}</b>
                <div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="section real-work" id="trabalhos">
          <div className="section-heading">
            <div>
              <p className="eyebrow dark">
                <span /> Equipamentos reais
              </p>
              <h2 className="display">
                Direto da <em>nossa bancada.</em>
              </h2>
            </div>
            <p>
              Alguns dos equipamentos que chegam à Oficina João Ferrari para diagnóstico, manutenção e
              recuperação.
            </p>
          </div>
          <div className="gallery-grid">
            {photos.map((photo, index) => (
              <figure
                className={photo.square ? `work-photo is-square photo-${index + 1}` : `work-photo photo-${index + 1}`}
                key={photo.src}
              >
                <span className="photo-backdrop" style={{ backgroundImage: `url(${photo.src})` }} aria-hidden="true" />
                <img
                  src={photo.src}
                  alt={photo.alt}
                  width={photo.w}
                  height={photo.h}
                  loading="lazy"
                  decoding="async"
                />
                <figcaption>
                  <span>0{index + 1}</span>
                  {photo.caption}
                </figcaption>
              </figure>
            ))}
          </div>
        </section>

        <section className="section" id="oficina">
          <div className="prevention-card">
            <div className="prevention-art">
              <div className="portrait-frame">
                <img
                  src="/oficina/joao-ferrari.webp"
                  alt="João Ferrari, responsável pela Oficina João Ferrari"
                  width="235"
                  height="378"
                  loading="lazy"
                />
                <span className="tag">
                  ATENDIMENTO DIRETO
                  <br />
                  COM JOÃO FERRARI
                </span>
              </div>
            </div>
            <div className="prevention-copy">
              <p className="eyebrow dark">
                <span /> Cuidado inteligente
              </p>
              <h2 className="display">
                Manutenção preventiva <em>protege seu investimento.</em>
              </h2>
              <p className="prose">
                Máquina parada atrasa o serviço. Uma revisão periódica ajuda a identificar desgaste antes que
                ele vire um reparo maior.
              </p>
              <ul>
                {checks.map((item) => (
                  <li key={item}>
                    <Check aria-hidden="true" />
                    {item}
                  </li>
                ))}
              </ul>
              <a
                className="primary"
                href={waLink("Olá, João! Gostaria de agendar uma revisão preventiva.")}
                target="_blank"
                rel="noreferrer"
              >
                <WhatsAppIcon /> Agendar revisão
              </a>
            </div>
          </div>
        </section>

        <section className="brands" aria-label="Marcas atendidas">
          <p>PRINCIPAIS MARCAS ATENDIDAS</p>
          <div className="brand-row">
            {brands.map((brand) => (
              <span key={brand}>{brand}</span>
            ))}
          </div>
          <small>Oficina multimarcas independente. As marcas pertencem aos seus respectivos proprietários.</small>
        </section>

        <section className="section faq" id="duvidas">
          <div className="faq-intro">
            <p className="eyebrow dark">
              <span /> Perguntas e respostas
            </p>
            <h2 className="display">
              Dúvidas antes de <em>trazer sua máquina?</em>
            </h2>
            <p className="prose">
              Aqui estão as respostas rápidas. Se ainda ficar alguma dúvida, fale diretamente com o João.
            </p>
            <a
              className="primary"
              href={waLink("Olá, João! Tenho uma dúvida sobre o atendimento da oficina.")}
              target="_blank"
              rel="noreferrer"
            >
              <WhatsAppIcon />
              <b>Tirar uma dúvida</b>
            </a>
          </div>
          <div className="faq-list">
            {faqs.map((item, index) => (
              <details key={item.q}>
                <summary>
                  <span>0{index + 1}</span>
                  <b>{item.q}</b>
                  <i className="faq-plus" aria-hidden="true">
                    +
                  </i>
                </summary>
                <p>{item.a}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="contact" id="contato">
          <p className="eyebrow">
            <span /> Vamos conversar?
          </p>
          <h2 className="display">
            Não deixe o equipamento <em>parado por mais tempo.</em>
          </h2>
          <p className="prose">Fale diretamente com João Ferrari e explique o que está acontecendo.</p>
          <div className="contact-stack">
            <a className="contact-button" href={WA_GERAL} target="_blank" rel="noreferrer">
              <span className="wa">
                <WhatsAppIcon />
              </span>
              <span>
                <small>ATENDIMENTO PELO WHATSAPP</small>
                <b>{WHATSAPP_DISPLAY}</b>
              </span>
            </a>
            <a className="contact-button phone-only" href={`tel:${PHONE_TEL}`}>
              <span className="wa">
                <Phone className="ui-icon" aria-hidden="true" />
              </span>
              <span>
                <small>TELEFONE PARA LIGAÇÕES</small>
                <b>{PHONE_DISPLAY}</b>
              </span>
            </a>
          </div>
        </section>
      </main>

      <footer>
        <a className="brand" href="#inicio">
          <img className="brand-logo" src="/oficina/logo-oficina.webp" alt="" width="900" height="900" />
          <span>
            <strong>OFICINA JOÃO FERRARI</strong>
            <small>Manutenção • Peças • Confiança</small>
          </span>
        </a>
        <address>
          <p>{ADDRESS.street}</p>
          <p>
            {ADDRESS.city} • São Paulo
          </p>
          <p>Atendimento com hora marcada</p>
          <p>
            <a href={`tel:${PHONE_TEL}`}>Telefone {PHONE_DISPLAY}</a>
          </p>
          <p>
            <a href={WA_GERAL} target="_blank" rel="noreferrer">
              WhatsApp {WHATSAPP_DISPLAY}
            </a>
          </p>
          <p>
            <a href={MAPS_URL} target="_blank" rel="noreferrer">
              <MapPin className="ui-icon" aria-hidden="true" /> Como chegar
            </a>
          </p>
        </address>
        <p>
          © {new Date().getFullYear()} Oficina João Ferrari
          <br />
          Oficina multimarcas independente.
        </p>
      </footer>

      <a className="whatsapp-float" href={WA_GERAL} target="_blank" rel="noreferrer" aria-label="Falar no WhatsApp">
        <WhatsAppIcon />
        <b>WhatsApp</b>
      </a>
    </>
  );
}

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
  }
}
