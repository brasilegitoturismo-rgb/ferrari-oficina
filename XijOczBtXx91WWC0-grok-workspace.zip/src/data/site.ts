export const PHONE_DISPLAY = "(17) 3199-0596";
export const PHONE_TEL = "+551731990596";
export const WHATSAPP_DISPLAY = "(17) 99117-3799";
export const WHATSAPP_TEL = "5517991173799";

export const ADDRESS = {
  street: "Rodovia Luiz Carlos Brandolezi, km 07",
  city: "Potirendaba",
  region: "SP",
  country: "BR",
};

export const MAPS_URL =
  "https://www.google.com/maps/search/?api=1&query=Rodovia%20Luiz%20Carlos%20Brandolezi%2C%20km%2007%2C%20Potirendaba%20-%20SP";

export function waLink(text: string) {
  return `https://wa.me/${WHATSAPP_TEL}?text=${encodeURIComponent(text)}`;
}

export const WA_GERAL = waLink(
  "Olá, João! Gostaria de solicitar um orçamento para meu equipamento.",
);

export const seo = {
  title: "Oficina João Ferrari | Motosserras e Roçadeiras em Potirendaba",
  description:
    "Assistência técnica em Potirendaba/SP para roçadeiras, motosserras, lavadoras, motores estacionários e motocultivadores. Orçamento antes do reparo e garantia.",
};

export const services = [
  {
    id: "rocadeiras",
    n: "01",
    title: "Roçadeiras",
    text: "Limpeza, regulagem, partida, embreagem e revisão completa.",
    glyph: "rocadeira",
    href: waLink("Olá, João! Gostaria de um orçamento para minha roçadeira."),
  },
  {
    id: "motosserras",
    n: "02",
    title: "Motosserras",
    text: "Diagnóstico, afiação, carburador, lubrificação e conjunto de corte.",
    glyph: "motosserra",
    href: waLink("Olá, João! Gostaria de um orçamento para minha motosserra."),
  },
  {
    id: "lavadoras",
    n: "03",
    title: "Lavadoras",
    text: "Reparo de bombas, vazamentos, perda de pressão e revisão preventiva.",
    glyph: "lavadora",
    href: waLink("Olá, João! Gostaria de um orçamento para minha lavadora."),
  },
  {
    id: "motores",
    n: "04",
    title: "Motores estacionários",
    text: "Manutenção em motores a gasolina de diferentes potências e marcas.",
    glyph: "motor",
    href: waLink(
      "Olá, João! Gostaria de um orçamento para meu motor estacionário.",
    ),
  },
  {
    id: "motocultivadores",
    n: "05",
    title: "Motocultivadores",
    text: "Revisão de motor, sistema de partida, transmissão e regulagens.",
    glyph: "cultivo",
    href: waLink("Olá, João! Gostaria de um orçamento para meu motocultivador."),
  },
  {
    id: "revisao",
    n: "06",
    title: "Revisão preventiva",
    text: "Check-up para reduzir falhas, gastos inesperados e tempo parado.",
    glyph: "revisao",
    href: waLink(
      "Olá, João! Gostaria de agendar uma revisão preventiva.",
    ),
  },
] as const;

export const steps = [
  {
    n: "01",
    title: "Conte o problema",
    text: "Envie uma mensagem com a marca, modelo e sintomas do equipamento.",
  },
  {
    n: "02",
    title: "Avaliação técnica",
    text: "O equipamento é inspecionado para localizar a causa real da falha.",
  },
  {
    n: "03",
    title: "Aprovação do orçamento",
    text: "Você recebe o valor antes do serviço e decide com tranquilidade.",
  },
  {
    n: "04",
    title: "Reparo, testes e entrega",
    text: "Depois do conserto, fazemos os testes necessários antes da retirada.",
  },
] as const;

export const photos = [
  {
    src: "/oficina/motosserra-stihl.webp",
    alt: "Motosserra Stihl recebida para manutenção na Oficina João Ferrari",
    caption: "Motosserras",
    w: 900,
    h: 1200,
    square: false,
  },
  {
    src: "/oficina/rocadeira-stihl.webp",
    alt: "Roçadeira Stihl na Oficina João Ferrari",
    caption: "Roçadeiras",
    w: 1200,
    h: 1200,
    square: true,
  },
  {
    src: "/oficina/motocultivador-kawashima.webp",
    alt: "Motocultivador Kawashima em revisão",
    caption: "Motocultivadores",
    w: 900,
    h: 1200,
    square: false,
  },
  {
    src: "/oficina/rocadeira-husqvarna.webp",
    alt: "Motor de roçadeira Husqvarna em avaliação",
    caption: "Diagnóstico",
    w: 1200,
    h: 1200,
    square: true,
  },
  {
    src: "/oficina/cortador-grama.webp",
    alt: "Cortador de grama na oficina",
    caption: "Motores em geral",
    w: 900,
    h: 1200,
    square: false,
  },
] as const;

export const brands = [
  "STIHL",
  "Husqvarna",
  "Branco",
  "Toyama",
  "Buffalo",
  "Kärcher",
  "Tekna",
  "Kawashima",
  "Trapp",
] as const;

export const checks = [
  "Limpeza e inspeção geral",
  "Verificação de filtros, vela e combustível",
  "Regulagem e teste de funcionamento",
  "Orientação para conservação e uso",
] as const;

export const faqs = [
  {
    q: "Quais equipamentos vocês consertam?",
    a: "Atendemos roçadeiras, motosserras, lavadoras, motores estacionários, motocultivadores, cortadores de grama e outros equipamentos a gasolina.",
  },
  {
    q: "Como funciona o orçamento?",
    a: "Primeiro fazemos a avaliação técnica para encontrar a causa da falha. Depois, você recebe o valor do serviço e das peças antes de autorizar o reparo.",
  },
  {
    q: "A oficina atende várias marcas?",
    a: "Sim. A Oficina João Ferrari é multimarcas e trabalha com equipamentos de fabricantes como STIHL, Husqvarna, Branco, Toyama, Buffalo, Kärcher, Tekna, Kawashima e Trapp.",
  },
  {
    q: "Preciso agendar o atendimento?",
    a: "O atendimento é feito com hora marcada. Chame no WhatsApp antes de levar o equipamento para combinarmos o melhor horário.",
  },
  {
    q: "O serviço tem garantia?",
    a: "Sim. A garantia varia conforme o tipo de reparo e as peças utilizadas; as condições são explicadas com clareza na entrega.",
  },
  {
    q: "Onde fica a Oficina João Ferrari?",
    a: "Estamos na Rodovia Luiz Carlos Brandolezi, km 07, em Potirendaba, São Paulo. O atendimento é com hora marcada.",
  },
] as const;

export const nav = [
  { href: "#servicos", label: "Serviços" },
  { href: "#processo", label: "Como funciona" },
  { href: "#oficina", label: "A oficina" },
  { href: "#duvidas", label: "Dúvidas" },
] as const;

export const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": ["AutoRepair", "LocalBusiness"],
      "@id": "#oficina-joao-ferrari",
      name: "Oficina João Ferrari",
      alternateName: ["Ferrari Oficina", "JF Oficina Especializada"],
      description: seo.description,
      slogan: "Manutenção, peças e confiança",
      telephone: ["+5517991173799", "+551731990596"],
      address: {
        "@type": "PostalAddress",
        streetAddress: ADDRESS.street,
        addressLocality: ADDRESS.city,
        addressRegion: ADDRESS.region,
        addressCountry: ADDRESS.country,
      },
      areaServed: [
        { "@type": "City", name: "Potirendaba" },
        { "@type": "AdministrativeArea", name: "São Paulo" },
      ],
      hasMap: MAPS_URL,
      currenciesAccepted: "BRL",
      knowsAbout: [
        "Manutenção de roçadeiras",
        "Manutenção de motosserras",
        "Lavadoras de alta pressão",
        "Motores estacionários a gasolina",
        "Motocultivadores",
        "Cortadores de grama",
      ],
      brand: brands.map((name) => ({ "@type": "Brand", name })),
      makesOffer: services.map((service) => ({
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: service.title,
          description: service.text,
          areaServed: "Potirendaba, SP",
          provider: { "@id": "#oficina-joao-ferrari" },
        },
      })),
    },
    {
      "@type": "FAQPage",
      mainEntity: faqs.map((item) => ({
        "@type": "Question",
        name: item.q,
        acceptedAnswer: { "@type": "Answer", text: item.a },
      })),
    },
  ],
};
