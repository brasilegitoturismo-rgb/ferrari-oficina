import { createFileRoute } from "@tanstack/react-router";
import { HomePage } from "@/components/home-page";
import { jsonLd, seo } from "@/data/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: seo.title },
      { name: "description", content: seo.description },
      { name: "robots", content: "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1" },
      { name: "author", content: "João Ferrari" },
      { name: "geo.region", content: "BR-SP" },
      { name: "geo.placename", content: "Potirendaba" },
      { name: "language", content: "pt-BR" },
      { name: "apple-mobile-web-app-title", content: "Oficina João Ferrari" },
      { "script:ld+json": jsonLd },
    ],
    links: [{ rel: "preload", href: "/oficina/logo-oficina.webp", as: "image" }],
  }),
  component: HomePage,
});
